import scrapy
from datetime import datetime
from ..items import MitreCweItem

class CweSpiderSpider(scrapy.Spider):
    name = "cwe_spider"
    allowed_domains = ["cwe.mitre.org"]
    start_urls = ["https://cwe.mitre.org/data/archive.html"]

    def parse(self, response):
        item = MitreCweItem()

        
        versions = response.css('div#ListPage table#StripedTable tr td:nth-child(1)::text').extract_first()
        links = response.css('div#ListPage table#StripedTable tr td:nth-child(2) a::attr(href)').extract_first()

        today = datetime.now()
        date = today.strftime("%d %b %Y")
        time = today.strftime("%H:%M")

        item['versions'] = versions
        item['links'] = links
        item['date'] = date
        item['time'] = time

        yield item
