import xml.etree.ElementTree as et

class DataProcess:
    def __getWeaknessID(weakness, weakness_dic):
        weakness_dic['id'] = 'CWE-'+ str(weakness.get('ID'))
    
    def __getWeaknessName(weakness, weakness_dic):
        weakness_dic['name'] = weakness.get('Name')

    def __getAbstraction(weakness, weakness_dic):
        weakness_dic['abstraction'] = weakness.get('Abstraction')

    def __getStructure(weakness, weakness_dic):
        weakness_dic['structure'] = weakness.get('Structure')

    def __getStatus(weakness, weakness_dic):
        weakness_dic['status'] = weakness.get('Status')


    def __Description(child, weakness_dic):
        if child.tag == '{http://cwe.mitre.org/cwe-6}Description':
            weakness_dic['description'] = child.text
    


    def __Extended_Description(child, weakness_dic):
        if child.tag == '{http://cwe.mitre.org/cwe-6}Extended_Description':
            extended_description = ''
            for p in child.iter():
                extended_description += str(p.text).strip()+' '
                weakness_dic['extended_description'] = extended_description.strip()



    def __Related_weaknesses(child, weakness_dic):
        if child.tag == '{http://cwe.mitre.org/cwe-6}Related_Weaknesses':
            Related_Weakness_list = []
            for Related_Weakness in child:
                if Related_Weakness.tag == '{http://cwe.mitre.org/cwe-6}Related_Weakness':
                    Related_Weakness_list.append(Related_Weakness.attrib)

            # add list of related weaknesses to  dictionary
            weakness_dic['related_weaknesses'] = Related_Weakness_list



    def __Applicable_Platforms(child, weakness_dic):
        if child.tag == '{http://cwe.mitre.org/cwe-6}Applicable_Platforms':
            Applicable_Platform_dict = dict()

            # get languages from Application_platforms tag
            language_list = []
            technology_list = []
            for subchild in child:
                if subchild.tag == '{http://cwe.mitre.org/cwe-6}Language':
                    language_list.append(subchild.attrib)


                    # add list of languages to application platfoms dictionary
                    Applicable_Platform_dict['language'] = language_list


                # for Technology in child:
                if subchild.tag == '{http://cwe.mitre.org/cwe-6}Technology':
                    technology_list.append(subchild.attrib)

                    # add list of technologies to application platforms dictionary
                    Applicable_Platform_dict['technology'] = technology_list

            # Add to the main weakness dictionary
            weakness_dic['applicable_platforms'] = Applicable_Platform_dict



    def __Background_Details(child, weakness_dic):
        if child.tag == '{http://cwe.mitre.org/cwe-6}Background_Details':
            background_detail = ""
            for li in child.iter():
                background_detail += str(li.text).strip() + ' '
            
            weakness_dic['background_details'] = background_detail.strip()


        
    def __Common_Consequences(child, weakness_dic):
        if child.tag == '{http://cwe.mitre.org/cwe-6}Common_Consequences':
            consequence_list = []
            for subchild in child:
                if subchild.tag == '{http://cwe.mitre.org/cwe-6}Consequence':
                    consequence_dict = {}
                    impact_list = []
                    note_list = []
                    scope_list = []
                    for i in subchild:

                        if i.tag == '{http://cwe.mitre.org/cwe-6}Scope':
                            scope_list.append(i.text)
                            consequence_dict['scope'] = scope_list

                        if i.tag == '{http://cwe.mitre.org/cwe-6}Impact':
                            impact_list.append(i.text)
                            consequence_dict['impact'] = impact_list

                        if i.tag == '{http://cwe.mitre.org/cwe-6}Note':
                            note_list.append(i.text)
                            consequence_dict['note'] = note_list

                    
                    consequence_list.append(consequence_dict)

            weakness_dic['common_consequences'] = consequence_list


            
            
            
    def __Modes_Of_Introduction(child, weakness_dic):
        if child.tag == '{http://cwe.mitre.org/cwe-6}Modes_Of_Introduction':
            introduction_list = []

            for subchild in child:
                if subchild.tag == '{http://cwe.mitre.org/cwe-6}Introduction':
                    introduction_dict = {}
                    phase_list = []
                    note_list = []

                    for i in subchild:
                        if i.tag == '{http://cwe.mitre.org/cwe-6}Phase':
                            phase_list.append(i.text)
                            introduction_dict['phase'] = phase_list

                        if i.tag == '{http://cwe.mitre.org/cwe-6}Note':
                            note_list.append(i.text)
                            introduction_dict['note'] = note_list


                    introduction_list.append(introduction_dict)
            weakness_dic['modes_of_introduction'] = introduction_list



    def __Weakness_Ordinality(child, weakness_dic):
        if child.tag == '{http://cwe.mitre.org/cwe-6}Weakness_Ordinalities':
            weakness_ordinality_list = []
            for subchild in child:
                if subchild.tag == '{http://cwe.mitre.org/cwe-6}Weakness_Ordinality':
                    weakness_ordinality_dict = {}
                    ordinality_list = []
                    description_list = []
                    for i in subchild:
                        if i.tag == '{http://cwe.mitre.org/cwe-6}Ordinality':
                            ordinality_list.append(i.text)
                            weakness_ordinality_dict['ordinality'] = ordinality_list

                        if i.tag == '{http://cwe.mitre.org/cwe-6}Description':
                            description_list.append(i.text)
                            weakness_ordinality_dict['description'] = description_list


                    weakness_ordinality_list.append(weakness_ordinality_dict)
            weakness_dic['weakness_ordinalities'] = weakness_ordinality_list




    def __Potential_Mitigations(child, weakness_dic):
        if child.tag == '{http://cwe.mitre.org/cwe-6}Potential_Mitigations':
            mitigation_list = []
            for subchild in child:
                if subchild.tag == '{http://cwe.mitre.org/cwe-6}Mitigation':
                    mitigation_dict = {}
                    phase_list = []
                    strategy_list = []
                    description = ""
                    effectiveness_list = []
                    effectiveness_notes = ""

                    if bool(subchild.attrib) == True:
                        mitigation_dict['mitigation_id'] = subchild.get('Mitigation_ID')

                    
                    for i in subchild.iter():
                        if i.tag == '{http://cwe.mitre.org/cwe-6}Phase':
                            phase_list.append(i.text)
                            mitigation_dict['phase'] = phase_list

                        if i.tag == '{http://cwe.mitre.org/cwe-6}Description':
                            for descrip in i.iter():
                                description += str(descrip.text).strip() +' '
                                mitigation_dict['description'] = description.strip()

                        if i.tag == '{http://cwe.mitre.org/cwe-6}Strategy':
                            strategy_list.append(i.text)
                            mitigation_dict['strategy'] = strategy_list

                        if i.tag == '{http://cwe.mitre.org/cwe-6}Effectiveness':
                            effectiveness_list.append(i.text)
                            mitigation_dict['effectiveness'] = effectiveness_list

                        if i.tag == '{http://cwe.mitre.org/cwe-6}Effectiveness_Notes':
                            effectiveness_notes += str(i.text).strip() + ' '
                            mitigation_dict['effectiveness_notes'] = effectiveness_notes.strip()

                    mitigation_list.append(mitigation_dict)
            weakness_dic['potential_mitigations'] = mitigation_list

    def __Likelihood_Of_Exploit(child, weakness_dic):
        if child.tag == '{http://cwe.mitre.org/cwe-6}Likelihood_Of_Exploit':
            weakness_dic['likelihood_of_exploit'] = child.text



    def __Demonstrative_Examples(child, weakness_dic):
        if child.tag == '{http://cwe.mitre.org/cwe-6}Demonstrative_Examples':
            Demonstrative_Examples_list = []

            for subchild in child.iter():
                if subchild.tag == '{http://cwe.mitre.org/cwe-6}Demonstrative_Example':
                    Demonstrative_Example_dict = {}
                    example = ""
                    example_details = []
                    for i in subchild.iter():
                        if i.tag == '{http://cwe.mitre.org/cwe-6}Intro_Text':
                            example += str(i.text).strip()+" "
                            # Demonstrative_Example_dict['example'] = example

                        if i.tag == '{http://cwe.mitre.org/cwe-6}Body_Text':
                            example += str(i.text).strip()+" "
                            # Demonstrative_Example_dict['Body_Text'] = body_text
                        
                        if i.tag == '{http://cwe.mitre.org/cwe-6}Example_Code':
                            example_details_dict = {}
                            example_details_dict['nature'] = i.get('Nature')
                            if 'Language' in i.attrib:
                                example_details_dict['language'] = i.get('Language')

                            for code in i.iter():
                                if code.text is not None:
                                    example += str(code.text).strip()+" "

                                if code.tail is not None:
                                    example += str(code.tail).strip()+" "

                            example_details.append(example_details_dict)

                    Demonstrative_Example_dict['example_details'] = example_details
                    Demonstrative_Example_dict['example'] = example.strip()

                    Demonstrative_Examples_list.append(Demonstrative_Example_dict) 
            weakness_dic['demonstrative_examples'] = Demonstrative_Examples_list




    def __Observed_Examples(child, weakness_dic):
        if child.tag == '{http://cwe.mitre.org/cwe-6}Observed_Examples':
            Observed_Examples_list = []

            for subchild in child:
                if subchild.tag == '{http://cwe.mitre.org/cwe-6}Observed_Example':
                    Observed_Example_dict = {}

                    for i in subchild.iter():
                        if i.tag == '{http://cwe.mitre.org/cwe-6}Reference':
                            Observed_Example_dict['reference'] = i.text
                        if i.tag == '{http://cwe.mitre.org/cwe-6}Description':
                            Observed_Example_dict['description'] = i.text
                        if i.tag == '{http://cwe.mitre.org/cwe-6}Link':
                            Observed_Example_dict['link'] = i.text


                    Observed_Examples_list.append(Observed_Example_dict)
            weakness_dic['observed_examples'] = Observed_Examples_list


    def __Detection_Methods(child, weakness_dic):
        if child.tag == '{http://cwe.mitre.org/cwe-6}Detection_Methods':
            Detection_Methods_list = []

            for subchild in child:
                if subchild.tag == '{http://cwe.mitre.org/cwe-6}Detection_Method':
                    Detection_Method_dict = {}
                    description = ''

                    for i in subchild.iter():
                        if i.tag == '{http://cwe.mitre.org/cwe-6}Method':
                            Detection_Method_dict['method'] = i.text

                        if i.tag == '{http://cwe.mitre.org/cwe-6}Description':
                            for descrip in i.iter():
                                description += str(descrip.text).strip() + ' '
                                Detection_Method_dict['description'] = description.strip()

                        if i.tag == '{http://cwe.mitre.org/cwe-6}Effectiveness':
                            Detection_Method_dict['effectiveness'] = i.text

                    Detection_Methods_list.append(Detection_Method_dict)

            weakness_dic['detection_methods'] = Detection_Methods_list



    def __Taxonomy_Mappings(child, weakness_dic):
        if child.tag == '{http://cwe.mitre.org/cwe-6}Taxonomy_Mappings':
            Taxonomy_Mappings_list = []

            for subchild in child.iter():
                if subchild.tag == '{http://cwe.mitre.org/cwe-6}Taxonomy_Mapping':
                    Taxonomy_Mapping_dict = {}
                    
                    Taxonomy_Mapping_dict['taxonomy_name'] = subchild.get('Taxonomy_Name')

                    for i in subchild.iter():
                        if i.tag == '{http://cwe.mitre.org/cwe-6}Entry_ID':
                            Taxonomy_Mapping_dict['entry_id'] = i.text

                        if i.tag == '{http://cwe.mitre.org/cwe-6}Entry_Name':
                            Taxonomy_Mapping_dict['entry_name'] = i.text

                    Taxonomy_Mappings_list.append(Taxonomy_Mapping_dict)

            weakness_dic['taxonomy_mappings'] = Taxonomy_Mappings_list





    @staticmethod
    def get_data():
        """get all data from xml and store into list of dictionaries"""
        xml_file = open("C:/Users/User/Desktop/DataProcess/cwec_v4.10.xml", "rb")
        tree = et.parse(xml_file)
        root = tree.getroot()

        list_of_weaknesses = []

        for weakness in root[0]:
            weakness_dic = dict()
            # print(weakness.attrib['ID'])

            DataProcess.__getWeaknessID(weakness, weakness_dic)
            DataProcess.__getWeaknessName(weakness, weakness_dic)
            DataProcess.__getAbstraction(weakness, weakness_dic)
            DataProcess.__getStructure(weakness, weakness_dic)
            DataProcess.__getStatus(weakness, weakness_dic)
           
            for child in weakness:
                DataProcess.__Description(child, weakness_dic)
                DataProcess.__Extended_Description(child, weakness_dic)
                DataProcess.__Related_weaknesses(child, weakness_dic)
                DataProcess.__Applicable_Platforms(child, weakness_dic)
                DataProcess.__Background_Details(child, weakness_dic)
                DataProcess.__Common_Consequences(child, weakness_dic)
                DataProcess.__Modes_Of_Introduction(child, weakness_dic)
                DataProcess.__Weakness_Ordinality(child, weakness_dic)
                DataProcess.__Potential_Mitigations(child, weakness_dic)
                DataProcess.__Likelihood_Of_Exploit(child, weakness_dic)
                DataProcess.__Observed_Examples(child, weakness_dic)
                DataProcess.__Detection_Methods(child, weakness_dic)
                DataProcess.__Taxonomy_Mappings(child, weakness_dic)
                DataProcess.__Demonstrative_Examples(child, weakness_dic)


            list_of_weaknesses.append(weakness_dic)

        return list_of_weaknesses




# print(DataProcess.get_data())
