import pymongo
from process_data import DataProcess
import re
import pprint

class InsertToDatabase:
    @staticmethod
    def connection():
        """"Connecting to database"""
        
        client = pymongo.MongoClient("mongodb+srv://CWE:cwe@cluster0.qw1btiy.mongodb.net/test")
        db = client['CWE_Data']
        col = db['cwes_test']

        return col
    
    
    @staticmethod
    def insert(collection):
        """insert list of weaknesses to the database"""

        weaknesses_list = DataProcess.get_data()

        data = collection.insert_many(weaknesses_list)

        # print("Total {} documents : ".format(len(data.inserted_ids)))
        # print("Data inserted successfully!")



    @staticmethod
    def add_owasp_categories(collection):
        """"add new fiels owasp_categories in every document which Toxonomy_Name contains OWASP"""

        query = { "taxonomy_mappings.taxonomy_name" : {"$regex" : "OWASP"}  }
        result =  collection.find(query, {"id" : 1, "taxonomy_mappings" : 1})
        
        def match(name):
            pattern = re.compile('OWASP')
            
            if pattern.match(name):
                return True
            else:
                return False


        for doc in result:
            owasp_category = []
            mapping_list = doc['taxonomy_mappings']
            for names in mapping_list:
                if match(names['taxonomy_name']):
                    owasp_category.append(names['entry_name'])

            collection.update_one({"id" : doc['id']}, {"$set" : {"owasp_category" : owasp_category}})

        # print("Data added successfully")



    @staticmethod
    def add_related_cves(collection):
        query = { "observed_examples" : { "$exists": True } }
        result = collection.find(query, {"observed_examples.reference" : 1, "id" : 1})

        for doc in result:
            observed_examples = doc['observed_examples']
            reference = []
            
            for ref in observed_examples:
                reference.append(ref['reference'])
            
            collection.update_one({"id" : doc['id']}, {"$set" : {"related_cves" : reference}})

        # print("Data added successfully")


    @staticmethod
    def distinct_owasp_category(collection):
        query = { "related_cves" : { "$exists": True }, "owasp_category" : {"$exists" : True} }
        result = collection.find(query, {"id" : 1, "owasp_category" : 1, "related_cves" : 1})

        # distinct_owasp = collection.distinct('owasp_category')
        owasp_dict = {}        
        for doc in result:
            print(doc['id'])
            temp = list(set(doc['owasp_category']))
            
            for owasp in temp:
                if owasp in owasp_dict:
                    owasp_dict[owasp] += list(set(doc['related_cves']))
                else:
                    owasp_dict[owasp] = doc['related_cves']

        return owasp_dict






col = InsertToDatabase.connection()
print("Connected to database....")

InsertToDatabase.insert(col)
print("All records inserted  successfully...!")

InsertToDatabase.add_related_cves(col)
print("Data added successfully!!!")

InsertToDatabase.add_owasp_categories(col)
print("Data added successfully!!!")
print("\nGo and Check .....")
# pprint.pprint(InsertToDatabase.distinct_owasp_category(col))
