import pymongo
import requests, zipfile
from io import BytesIO
from urllib.request import urlopen
from zipfile import ZipFile
import wget


class DownloadFeedData:
    # Connecting to database
    @staticmethod
    def ConnectToDb():
        return pymongo.MongoClient('mongodb+srv://CWE:cwe@cluster0.qw1btiy.mongodb.net/test')


    # Extracting dta from database
    @staticmethod
    def getData(conn):
        db = conn.CWE_Data
        collection = db.CWE_DataFeeds
        data = list(collection.find())
        # col_len = len(data)

        return data[-1]['links']


    # Downloading zip files from url
    @staticmethod
    def DownloadFile(url):
        return wget.download(url)



    # Extracting zip file
    @staticmethod
    def ExtractFile(file):
        with zipfile.ZipFile(file,"r") as zip_ref:
            zip_ref.extractall()


    # Extract data from link
    @staticmethod
    def ExtractFromURL(url):
        response = requests.get(url)
        file = zipfile.ZipFile(BytesIO(response.content))
        file.extractall()






print("Connecting to Database...")
conn = DownloadFeedData.ConnectToDb()
print("Connected!\n")


link = DownloadFeedData.getData(conn)
url = 'https://cwe.mitre.org'+link

print("Downloading zip file...")
# file = DownloadFile(url)
print("Downloaded!")

print("\nExtracting file...")
DownloadFeedData.ExtractFromURL(url)
# DownloadFeedData.ExtractFile(file)
print("Extracted!")










# print("Downloading data...")

# print("Extracting data...")
# # response = DownloadFile(col)
# # ExtractFile(response)
# print("Data Extracted!")


