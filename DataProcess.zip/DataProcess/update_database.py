import pymongo
from pymongo import UpdateOne
from process_data import DataProcess
import timeit
from datetime import timedelta


class UpdateDatabase:
    @staticmethod
    def connection():
        """"Connecting to database"""
        
        client = pymongo.MongoClient("mongodb+srv://CWE:cwe@cluster0.qw1btiy.mongodb.net/test")
        db = client['CWE_Data']
        col = db['cwes_test']
        
        return col
    
    @staticmethod
    def update(collection):
        weaknesses = DataProcess.get_data()

        for cwe in weaknesses:
            cwe_keys = list(cwe.keys())
            for key in cwe_keys:
                collection.update_one(
                    {'id' : cwe['id']},
                    {'$set': { key : cwe[key]}},
                    upsert = True )
        

    # @staticmethod
    # def update(collection):
    #     new_data = DataProcess.get_data()

    #     # count = collection.estimated_document_count()
    #     # old_data = collection.find().batch_size(count)

    #     for new_cwe in new_data:
    #         for key, value in new_cwe.items():
    #             collection.bulk_write([
    #                 UpdateOne(
    #                     {'id' : new_cwe['id']},
    #                     {'$set' : {key : value}},
    #                     upsert = True
    #                 )
    #             ])


                
start = timeit.timeit()
print("Start : ", start)
print("Updating")
col = UpdateDatabase.connection()
UpdateDatabase.update(col)
print("Updated Successfull!")
end = timeit.timeit()

print("End : ", end)
print("Time taken : ", (end-start))





# client = pymongo.MongoClient("mongodb+srv://CWE:cwe@cluster0.qw1btiy.mongodb.net/test")
# db = client['CWE_Data']
# col = db['test']

# count = col.estimated_document_count()

# result = col.find().batch_size(count)

# for item in result:
#     print(item)


