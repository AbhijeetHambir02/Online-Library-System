from process_data import DataProcess
import pandas
import os
import re


filename = ""
for f in os.listdir('.'):
    if re.search('xml$', f):
        filename = f[:-4]        


def convert_to_csv():
    weaknesses_list = DataProcess.get_data()

    keys = set().union(*(k.keys() for k in weaknesses_list))
    df  = pandas.DataFrame(weaknesses_list)
    df.to_csv(filename+".csv", index=False, header=True)



# convert_to_csv()
print("Converted to csv successfully!")





























# cwe_file = open("b.csv", "w")
# dict_writer = csv.DictWriter(cwe_file, fieldnames=keys)
# dict_writer.writeheader()
# dict_writer.writerows(weaknesses_list)

# cwe_file.close()






# xml_file = open("C:/Users/User/Desktop/DataProcess/cwec_v4.9.xml", "rb")
# tree = et.parse(xml_file)
# root = tree.getroot()

# data =pd.DataProcess.getData(root)

# keys = data[0].keys()

# with open('cwe.csv', 'w', newline='') as output_file:
#     dict_writer = csv.DictWriter(output_file, keys)
#     dict_writer.writeheader()
#     dict_writer.writerows(data)